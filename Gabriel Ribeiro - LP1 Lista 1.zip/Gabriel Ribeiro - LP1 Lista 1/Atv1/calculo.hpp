#ifndef calculo_hpp
#define calculo_hpp

float area_quadrado(float);
float area_retangulo( float , float );
float area_triangulo(float , float );
float area_circulo(float );

#endif